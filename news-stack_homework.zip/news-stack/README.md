# News Stack

Node package 설치
```
npm install
```

서버 실행
```
supervisor app.js
```

랄랄랄ㄹ랄랄
오늘은 어려운 거를 하는구나 참으로 어렵구ㅏ 
push 되는지 확인해야지